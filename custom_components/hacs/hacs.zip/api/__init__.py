"""Initialize HACS API"""
